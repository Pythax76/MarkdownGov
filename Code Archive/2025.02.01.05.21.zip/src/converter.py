# Markdown to Word conversion logic

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
import markdown
import os
import re

class MarkdownToWordConverter:
    def __init__(self):
        self.current_level = 1  # Default paragraph level (changes based on last header)

    def convert(self, template_path, markdown_path, output_dir):
        """Converts a Markdown file into a Word document using a template."""
        # Load the Word template
        doc = Document(template_path)

        # Read Markdown content
        with open(markdown_path, 'r', encoding='utf-8') as md_file:
            md_content = md_file.read()

        # Convert Markdown to Word format
        self._parse_markdown_to_word(md_content, doc)

        # Apply metadata
        self._apply_metadata(doc, markdown_path)

        # Generate output file path
        base_name = os.path.splitext(os.path.basename(markdown_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}.docx")

        # Save the new Word document
        doc.save(output_path)

        return output_path

    def _parse_markdown_to_word(self, md_content, doc):
        """Parses Markdown content and applies formatting in Word."""
        lines = md_content.split("\n")

        for line in lines:
            if line.strip() == "":
                doc.add_paragraph()  # Add empty line
                continue

            # Headers (H1 to H6)
            match = re.match(r'^(#{1,6})\s*(.*)', line)
            if match:
                level = len(match.group(1))  # Count number of '#' to determine header level
                text = match.group(2)
                self.current_level = level  # Update paragraph level based on the header
                self._add_heading(doc, text, level)
                continue

            # Lists (Bullets and Numbered)
            if re.match(r'^[-*+]\s+', line):  # Unordered list
                self._add_list_item(doc, line[2:], ordered=False)
                continue
            elif re.match(r'^\d+\.\s+', line):  # Ordered list
                self._add_list_item(doc, line[3:], ordered=True)
                continue

            # Blockquotes
            if line.startswith(">"):
                self._add_blockquote(doc, line[1:].strip())
                continue

            # Inline Code
            if re.match(r'`(.*?)`', line):
                line = re.sub(r'`(.*?)`', r'\1', line)  # Remove Markdown inline code formatting
                self._add_code_block(doc, line)
                continue

            # Apply paragraph level to normal text
            self._add_body_text(doc, line, self.current_level)

    def _add_heading(self, doc, text, level):
        """Adds a header with appropriate Word style."""
        doc.add_heading(text, level - 1)  # Word uses levels 0-4, Markdown uses 1-6

    def _add_list_item(self, doc, text, ordered):
        """Adds a list item (ordered or unordered)."""
        para = doc.add_paragraph(text, style="List Number" if ordered else "List Bullet")

    def _add_blockquote(self, doc, text):
        """Adds a blockquote with italic styling."""
        para = doc.add_paragraph(text)
        para.style = 'Quote'

    def _add_code_block(self, doc, text):
        """Adds inline code as monospaced text."""
        para = doc.add_paragraph(text)
        para.style = 'Code'

    def _add_body_text(self, doc, text, level):
        """Adds normal paragraph text, aligning it to the last known header level."""
        para = doc.add_paragraph(text)
        para.style = f'Body Text {level}' if level > 1 else 'Normal'

# The converter now ensures that body text aligns with the last used header's paragraph level.
